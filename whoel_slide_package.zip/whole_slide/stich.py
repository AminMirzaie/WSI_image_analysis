from registration import generateCoefficents, clipper, rescale, align_channel
import glob
import numpy as np
import cv2
import gc
import time
import concurrent.futures


class Sticher:
    def __init__(self, transformation_matrix_path, base_folder, background_path, thread_number, out_dir_path = None):
        self.BR_h = np.loadtxt(transformation_matrix_path + "transformation_matrix/BR_h.txt")
        self.GR_h = np.loadtxt(transformation_matrix_path + "transformation_matrix/GR_h.txt")
        self.base_folder = base_folder
        self.num_lines = len(glob.glob(self.base_folder + "*.tif")) // 3
        self.images = {}
        self.coefs = generateCoefficents(background_path)
        self.thread_number = thread_number

    def reading_images(self, img_num):
        print(img_num)
        R = clipper(cv2.imread(self.base_folder + "line_" + str(img_num) + "_c1.tif", cv2.IMREAD_UNCHANGED)[:, :-10])
        G = clipper(cv2.imread(self.base_folder + "line_" + str(img_num) + "_c2.tif", cv2.IMREAD_UNCHANGED)[:, :-10])
        B = clipper(cv2.imread(self.base_folder + "line_" + str(img_num) + "_c3.tif", cv2.IMREAD_UNCHANGED)[:, :-10])

        self.images[img_num] = np.clip(
            cv2.merge([
                rescale(R * self.coefs[0]),
                align_channel(rescale(G * self.coefs[1]), self.GR_h),
                align_channel(rescale(B * self.coefs[2]), self.BR_h)
            ]), 0, 255).astype("uint8")[5:-5, 5:-10]

        del (R)
        del (G)
        del (B)
        gc.collect()
        return img_num

    def stich_lines(self):
        img_nums = list(range(self.num_lines))
        t1 = time.perf_counter()
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.thread_number) as executor:
            results = executor.map(self.reading_images, img_nums)
        concurrent.futures.as_completed(results)
        t2 = time.perf_counter()
        print(t2 - t1)
        return 1